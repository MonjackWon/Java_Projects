package Schoolwork.entranceControl.validate;

public interface Validate {
    boolean check(String input);
}
